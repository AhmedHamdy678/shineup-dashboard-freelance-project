/**
 * Settings page — placeholder for platform-wide configuration,
 * such as cancellation rules, commission rates, and service categories.
 */
import Card from '../../../shared/components/ui/Card';

export default function SettingsPage() {
  return (
    <div className="space-y-4">
      <h3 className="text-base font-semibold text-gray-800">الإعدادات</h3>
      <Card>
        <div className="flex flex-col items-center justify-center py-20 text-gray-400">
          <svg className="w-16 h-16 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
          </svg>
          <p className="text-lg font-medium">الإعدادات قريباً</p>
          <p className="text-sm mt-1">تكوين المنصة مثل قواعد العمولة وسياسات الإلغاء وفئات الخدمات.</p>
        </div>
      </Card>
    </div>
  );
}
